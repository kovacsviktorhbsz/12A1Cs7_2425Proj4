﻿using pizzeria.Database;
using pizzeria.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pizzeria
{
    /// <summary>
    /// Interaction logic for pizza.xaml
    /// </summary>
    public partial class pizza : Window
    {
        private PizzeriaContext ctx = new PizzeriaContext();
        public pizza()
        {
            InitializeComponent();
            LoadPizzak();
        }
        // Database => Listbox
        private void LoadPizzak()
        {
            lbPizzaList.Items.Clear(); // Kitörli az eddig itemeket
            var pizzaList = ctx.Pizzak.ToList(); // Kigyűjti az adatbázisból a pizzákat

            foreach (var pizza in pizzaList)
            {
                lbPizzaList.Items.Add(pizza.Pnev); // Pizza neve bekerül a listboxba
            }
        }
        // törlés
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (lbPizzaList.SelectedItem == null) return; // Ha semmi nincs kiválasztva nem történik semmi

            string selectedName = lbPizzaList.SelectedItem.ToString();
            var pizzaToDelete = ctx.Pizzak.FirstOrDefault(x => x.Pnev == selectedName); // Név alapján megkeressük a db-ból a pizzát

            if (pizzaToDelete != null)
            {
                ctx.Pizzak.Remove(pizzaToDelete); // törlés
                ctx.SaveChanges(); // commit
                LoadPizzak(); // Lista újratöltése
            }
        }
        // módosítás
        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (lbPizzaList.SelectedItem == null) return; // Ha semmi nincs kiválasztva nem történik semmi

            // validálás, != üres
            if (string.IsNullOrEmpty(pizzaaz.Text) || string.IsNullOrEmpty(pizzanev.Text) || string.IsNullOrEmpty(pizzaar.Text))
            {
                MessageBox.Show("Adj meg adatokat.");
                return;
            }

            int pizzaId = int.Parse(pizzaaz.Text); // id
            var pizzaToUpdate = ctx.Pizzak.FirstOrDefault(x => x.PizzaId == pizzaId); // id alapján azonosítunk

            if (pizzaToUpdate != null)
            {
                pizzaToUpdate.Pnev = pizzanev.Text; // módosítja a nevet
                pizzaToUpdate.Par = pizzaar.Text; // módosítja az árat
                pizzaToUpdate.PizzaId = pizzaId; // id

                ctx.SaveChanges(); // Commit
                LoadPizzak(); // lista újratöltése
            }
        }
        // hozzáadás
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            // validálás, != üres
            if (string.IsNullOrEmpty(pizzanev.Text) || string.IsNullOrEmpty(pizzaar.Text))
            {
                MessageBox.Show("Add meg az adatokat!");
                return;
            }

            // új pizza object
            var newPizza = new Pizza
            {
                Pnev = pizzanev.Text,
                PizzaId = int.Parse(pizzaaz.Text),
                Par = pizzaar.Text,
            };

            ctx.Pizzak.Add(newPizza); // hozzáadás
            ctx.SaveChanges(); // Commit
            LoadPizzak(); // lista újratöltése
        }

        private void tbSzures_TextChanged(object sender, TextChangedEventArgs e)
        {
            // szövegrészlet
            string filterText = tbSzures.Text.ToLower();  // case-insensitive

            // Filter Pizza itemek
            var filteredList = ctx.Pizzak
                                  .Where(x => x.Pnev.ToLower().Contains(filterText)) // név alapján való szűrés
                                  .ToList();

            // lista törlése
            lbPizzaList.Items.Clear();

            foreach (var pizza in filteredList)
            {
                lbPizzaList.Items.Add(pizza.Pnev);  // szűrt nevek visszahelyezése
            }
        }
    }
}
