﻿using pizzeria.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pizzeria.Database
{
    internal class PizzeriaContext : DbContext
    {
        public DbSet<Futar> Futarok { get; set; }
        public DbSet<Pizza> Pizzak {  get; set; }
        public DbSet<Rendeles> Rendelesek { get; set; }
        public DbSet<Tetel> Tetelek { get; set; }
        public DbSet<Vevo> Vevok { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            modelBuilder.Entity<Tetel>()
            .HasKey(t => new { t.RendelesId, t.PizzaId });
        }
    }
}
