﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pizzeria.Models
{
    internal class Rendeles
    {
        public int RendelesId { get; set; }
        public int FutarId { get; set; }
        public virtual Futar Futar { get; set; }
        public int VevoId { get; set; }
        public virtual Vevo Vevo { get; set; }
        public DateTime Idopont { get; set; }
    }
}
