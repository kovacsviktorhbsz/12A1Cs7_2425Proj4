﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pizzeria.Models
{
    internal class Pizza
    {
        public int PizzaId { get; set; }
        public string Pnev { get; set; }
        public string Par { get; set; }
    }
}
