﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pizzeria.Models
{
    internal class Tetel
    {
        public int PizzaId { get; set; }
        public virtual Pizza Pizza { get; set; }
        public int RendelesId { get; set; }
        public virtual Rendeles Rendeles { get; set; }
        public int Db { get; set; }
    }
}
