﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pizzeria.Models
{
    internal class Futar
    {
        public int FutarId {  get; set; }
        public string Fnev { get; set; }
        public string Tel { get; set; }
    }
}
