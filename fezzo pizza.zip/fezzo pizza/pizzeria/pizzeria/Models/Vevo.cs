﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pizzeria.Models
{
    internal class Vevo
    {
        public int VevoId { get; set;}
        public string Vnev { get; set;}
        public string Vcim { get; set;}
    }
}
