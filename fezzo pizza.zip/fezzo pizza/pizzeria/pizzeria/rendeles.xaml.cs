﻿using pizzeria.Database;
using pizzeria.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pizzeria
{
    /// <summary>
    /// Interaction logic for rendeles.xaml
    /// </summary>
    public partial class rendeles : Window
    {
        private PizzeriaContext ctx = new PizzeriaContext();
        public rendeles()
        {
            InitializeComponent();
            LoadRendelesek();
        }
        // Database => Listbox
        private void LoadRendelesek()
        {
            lbRendelesList.Items.Clear(); // Kitörli az eddig itemeket
            var rendelesList = ctx.Rendelesek.ToList(); // Kigyűjti az adatbázisból a futárokat

            foreach (var rendeles in rendelesList)
            {
                lbRendelesList.Items.Add(rendeles.RendelesId); // rendelés id-ja bekerül a listboxba
            }
        }
        // törlés
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (lbRendelesList.SelectedItem == null) return; // Ha semmi nincs kiválasztva nem történik semmi

            int selectedId = (int)lbRendelesList.SelectedItem;
            var rendelesToDelete = ctx.Rendelesek.FirstOrDefault(x => x.RendelesId == selectedId); // Név alapján megkeressük a db-ból a rendelést

            if (rendelesToDelete != null)
            {
                ctx.Rendelesek.Remove(rendelesToDelete); // törlés
                ctx.SaveChanges(); // commit
                LoadRendelesek(); // Lista újratöltése
            }
        }
        // Kiválasztott rendelést módósítja
        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (lbRendelesList.SelectedItem == null) return; // Ha semmi nincs kiválasztva nem történik semmi

            // validálás, != üres
            if (string.IsNullOrEmpty(rendelesaz.Text) || string.IsNullOrEmpty(rendelesvevo.Text) || string.IsNullOrEmpty(rendelesfutar.Text))
            {
                MessageBox.Show("Adj meg adatokat.");
                return;
            }

            int rendelesId = int.Parse(rendelesaz.Text); // id
            var rendelesToUpdate = ctx.Rendelesek.FirstOrDefault(x => x.RendelesId == rendelesId); // id alapján azonosítunk

            if (rendelesToUpdate != null)
            {
                rendelesToUpdate.RendelesId = int.Parse(rendelesaz.Text); // módosítja az id-t
                rendelesToUpdate.VevoId = int.Parse(rendelesvevo.Text); // módosítja a vevőid-t
                rendelesToUpdate.FutarId = int.Parse(rendelesfutar.Text); // futár id
                rendelesToUpdate.Idopont = DateTime.Parse(rendelesido.Text); // idő

                ctx.SaveChanges(); // Commit
                LoadRendelesek(); // lista újratöltése
            }
        }
        // hozzáadás
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            // validálás, != üres
            if (string.IsNullOrEmpty(rendelesaz.Text) || string.IsNullOrEmpty(rendelesvevo.Text) || string.IsNullOrEmpty(rendelesfutar.Text) || string.IsNullOrEmpty(rendelesido.Text))
            {
                MessageBox.Show("Add meg az adatokat!");
                return;
            }

            // új rendelés object
            var newRendeles = new Rendeles
            {
                RendelesId = int.Parse(rendelesaz.Text),
                VevoId = int.Parse(rendelesvevo.Text),
                FutarId = int.Parse(rendelesfutar.Text),
                Idopont = DateTime.Parse(rendelesido.Text)
            };

            ctx.Rendelesek.Add(newRendeles); // hozzáadás
            ctx.SaveChanges(); // Commit
            LoadRendelesek(); // lista újratöltése
        }
    }
}
