﻿using System;
using pizzeria.Database;
using pizzeria.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pizzeria
{
    /// <summary>
    /// Interaction logic for futar.xaml
    /// </summary>
    public partial class futar : Window
    {
        private PizzeriaContext ctx = new PizzeriaContext();
        public futar()
        {
            InitializeComponent();
            LoadFutarok();
            
        }
        // Database => Listbox
        private void LoadFutarok()
        {
            lbFutarList.Items.Clear(); // Kitörli az eddig itemeket
            var futarList = ctx.Futarok.ToList(); // Kigyűjti az adatbázisból a futárokat

            foreach (var futar in futarList)
            {
                lbFutarList.Items.Add(futar.Fnev); // Futár neve bekerül a listboxba
            }
        }
        // törlés
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (lbFutarList.SelectedItem == null) return; // Ha semmi nincs kiválasztva nem történik semmi

            string selectedName = lbFutarList.SelectedItem.ToString();
            var futarToDelete = ctx.Futarok.FirstOrDefault(x => x.Fnev == selectedName); // Név alapján megkeressük a db-ból a futárt

            if (futarToDelete != null)
            {
                ctx.Futarok.Remove(futarToDelete); // törlés
                ctx.SaveChanges(); // commit
                LoadFutarok(); // Lista újratöltése
            }
        }
        // Kiválasztott futárt módósítja
        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (lbFutarList.SelectedItem == null) return; // Ha semmi nincs kiválasztva nem történik semmi

            // validálás, != üres
            if (string.IsNullOrEmpty(futaraz.Text) || string.IsNullOrEmpty(futarnev.Text) || string.IsNullOrEmpty(futartel.Text))
            {
                MessageBox.Show("Adj meg adatokat.");
                return;
            }

            int futarId = int.Parse(futaraz.Text); // id
            var futarToUpdate = ctx.Futarok.FirstOrDefault(x => x.FutarId == futarId); // id alapján azonosítunk

            if (futarToUpdate != null)
            {
                futarToUpdate.Fnev = futarnev.Text; // módosítja a nevet
                futarToUpdate.Tel = futartel.Text; // módosítja a telszámot
                futarToUpdate.FutarId = futarId;

                ctx.SaveChanges(); // Commit
                LoadFutarok(); // lista újratöltése
            }
        }
        // hozzáadás
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            // validálás, != üres
            if (string.IsNullOrEmpty(futarnev.Text) || string.IsNullOrEmpty(futartel.Text))
            {
                MessageBox.Show("Add meg az adatokat!");
                return;
            }

            // új futár object
            var newFutar = new Futar
            {
                Fnev = futarnev.Text,
                FutarId = int.Parse(futaraz.Text),
                Tel = futartel.Text,
            };

            ctx.Futarok.Add(newFutar); // hozzáadás
            ctx.SaveChanges(); // Commit
            LoadFutarok(); // lista újratöltése
        }

        private void tbSzures_TextChanged(object sender, TextChangedEventArgs e)
        {
            // szövegrészlet
            string filterText = tbSzures.Text.ToLower();  // case-insensitive

            // Filter Futár itemek
            var filteredList = ctx.Futarok
                                  .Where(x => x.Fnev.ToLower().Contains(filterText)) // név alapján való szűrés
                                  .ToList();

            // lista törlése
            lbFutarList.Items.Clear();

            foreach (var futar in filteredList)
            {
                lbFutarList.Items.Add(futar.Fnev);  // szűrt nevek visszahelyezése
            }
        }
    }
}
