﻿using pizzeria.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pizzeria
{
    /// <summary>
    /// Interaction logic for tovabb.xaml
    /// </summary>
    public partial class tovabb : Window
    {
        private PizzeriaContext ctx = new PizzeriaContext(); 
        public tovabb()
        {
            InitializeComponent();
        }

        private void cbtovabb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // ha nincs kiválasztva semmi nem történik semmi
            if (cbtovabb.SelectedItem == null)
                return;


            string selectedOption = (cbtovabb.SelectedItem as ComboBoxItem).Content.ToString();

            // külön választások eldöntése
            if (selectedOption == "Legolcsóbb pizza")
            {
                // legolcsóbb
                var leastExpensive = ctx.Pizzak.OrderBy(x => x.Par).FirstOrDefault();
                tbtovabb.Text = leastExpensive != null ? leastExpensive.Pnev : "Nincs ilyen pizza";
            }
            else if (selectedOption == "Legdrágább pizza")
            {
                // legdrágább
                var mostExpensive = ctx.Pizzak.OrderByDescending(x => x.Par).FirstOrDefault();
                tbtovabb.Text = mostExpensive != null ? mostExpensive.Pnev : "Nincs ilyen pizza";
            }
            else if (selectedOption == "Pizzák átlagos ára")
            {
                // átlag
                var averagePrice = ctx.Pizzak.Average(x => x.Par);
                tbtovabb.Text = $"Ár átlag: {averagePrice}";
            }
        }
    }
}
